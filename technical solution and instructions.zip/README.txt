PLEASE IGNORE:
- auth test.py
- cred.py
- gui tests.py
- tekore test.py
- tkinter auth test.py
- url retrieval.py


DEPENDENCIES

To install the dependencies, navigate to the cloned directory in Terminal or Command Prompt and use the command:

pip install -r requirements.txt

To use the VLC module, please install VLC from:

https://www.videolan.org/vlc/


FOR EXAMINERS

Due to limitations by Spotify for schoolwork programs, please use the example Spotify account to log in:

Email: exampleexaminer@gmail.com
Username: 31cskad4iqej67l4vdl3oeipfh5i
Password: &kf940%F!ynI

If this account is not used then the program will not be able to run, even if logged in with a personal Spotify account.
If logging in requires e-mail verification, use the same details above on Gmail.

RUNNING

When running for the first time, or if the config file does not exist / cannot be found make sure you:

- Log into Spotify when the window opens.
- Authorise the program to access data.
- Copy the URL of the example domain tab.
- Paste the FULL URL after the program prompt.

There may be slight issues with modules between each OS. This was made and bug tested using both MacOS and Windows.